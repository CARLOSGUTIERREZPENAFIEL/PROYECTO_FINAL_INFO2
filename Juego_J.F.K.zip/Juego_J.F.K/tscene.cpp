#include "tscene.h"

TScene::TScene(QObject *parent) : QGraphicsScene(parent), backgroundOffsetX(0)
{
    initializeScene();
    QImage imagen_fondo(":/imagenes/escenario.png");
    QBrush fondo_escenario(imagen_fondo);
    setBackgroundBrush(fondo_escenario);

    connect(personaje1, &Personaje::moveBackground, this, &TScene::onMoveBackground);
}

void TScene::initializeScene()
{
    setSceneRect(0, 30, 1920, 1080);
    QPixmap PM(":/imagenes/caja");
    personaje1 = new Personaje();
    addItem(personaje1);
    personaje1->setFocus();
}

void TScene::onMoveBackground(int dx)
{
    backgroundOffsetX += dx;
    setSceneRect(backgroundOffsetX, 30, 1920, 1080);  // Ajustar la posición del fondo
}
